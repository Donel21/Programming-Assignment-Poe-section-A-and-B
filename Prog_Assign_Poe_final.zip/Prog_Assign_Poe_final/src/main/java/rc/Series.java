package rc;

import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);

   
    public void captureSeries() {
        System.out.println("*******************************************");
        System.out.println("Capture a NEW series");

        System.out.print("Enter the series id: ");
        String id = sc.nextLine();

        System.out.print("Enter the series name: ");
        String name = sc.nextLine();

        int age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            String input = sc.nextLine();
            try {
                age = Integer.parseInt(input);
                if (age >= 2 && age <= 18) break;
                else System.out.println("You have entered an incorrect series age !!! Please enter between 2 and 18.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number between 2 and 18.");
            }
        }

        System.out.print("Enter the number of episodes for " + name + ": ");
        int episodes = Integer.parseInt(sc.nextLine());

        addSeries(id, name, age, episodes);
        System.out.println("Series processed successfully!!!");
    }

   

    // Add series 
    public void addSeries(String id, String name, int age, int episodes) {
        SeriesModel newSeries = new SeriesModel(id, name, age, episodes);
        seriesList.add(newSeries);
    }

    // Search by id
    public SeriesModel searchSeries(String id) {
        for (SeriesModel s : seriesList) {
            if (s.getSeriesId().equals(id)) {
                return s;
            }
        }
        return null;
    }

    // Update by id
    public boolean updateSeries(String id, String newName, int newAge) {
        SeriesModel found = searchSeries(id);
        if (found != null) {
            found.setSeriesName(newName);
            found.setSeriesAge(newAge);
            return true;
        }
        return false;
    }

    // Delete by id
    public boolean deleteSeries(String id) {
        SeriesModel found = searchSeries(id);
        if (found != null) {
            seriesList.remove(found);
            return true;
        }
        return false;
    }

    // Check age restriction
    public boolean checkAgeRestriction(int age) {
        return age >= 2 && age <= 18;
    }

    //Search Series
    public void searchSeries() {
        System.out.print("Enter the series id to search: ");
        String id = sc.nextLine();
        SeriesModel found = searchSeries(id);

        if (found != null) {
            System.out.println("------------------------------------");
            System.out.println(found);
        } else {
            System.out.println("Series with series id: " + id + " was not found!");
        }
    }

    public void updateSeries() {
        System.out.print("Enter the series id to update: ");
        String id = sc.nextLine();
        SeriesModel found = searchSeries(id);

        if (found != null) {
            System.out.print("Enter the series name: ");
            found.setSeriesName(sc.nextLine());

            int age;
            while (true) {
                System.out.print("Enter the age restriction: ");
                String input = sc.nextLine();
                try {
                    age = Integer.parseInt(input);
                    if (age >= 2 && age <= 18) {
                        found.setSeriesAge(age);
                        break;
                    } else {
                        System.out.println("Invalid! Enter between 2 and 18.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number! Try again.");
                }
            }

            System.out.print("Enter the number of episodes: ");
            found.setNumberOfEpisodes(Integer.parseInt(sc.nextLine()));

            System.out.println("Series updated successfully!");
        } else {
            System.out.println("Series not found!");
        }
    }

    public void deleteSeries() {
        System.out.print("Enter the series id to delete: ");
        String id = sc.nextLine();
        if (deleteSeries(id)) {
            System.out.println("Series with series id: " + id + " was deleted!");
        } else {
            System.out.println("Series not found!");
        }
    }

    public void seriesReport() {
        System.out.println("--------------- SERIES REPORT 2025 ----------------");
        int count = 1;
        for (SeriesModel s : seriesList) {
            System.out.println("Series " + count++);
            System.out.println("-----------------------------------");
            System.out.println(s);
        }
    }

    public void exitSeriesApplication() {
        System.out.println("Exiting application...");
        System.exit(0);
    }
}
