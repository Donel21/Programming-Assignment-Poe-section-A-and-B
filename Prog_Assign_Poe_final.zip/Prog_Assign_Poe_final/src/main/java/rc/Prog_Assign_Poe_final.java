package rc;

import java.util.Scanner;

// Main class to launch the application
public class Prog_Assign_Poe_final {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Series seriesManager = new Series();
//loop
        while (true) {
            System.out.println("\nLatest series 2025");
            System.out.println("********************************************************");
            System.out.println("Please select one of the following menu items:");
            System.out.println("1. Capture a new series");
            System.out.println("2. Search for series");
            System.out.println("3. Update series age restriction");
            System.out.println("4. Delete a series");
            System.out.println("5. Print series report – 2025");
            System.out.println("6. Exit application");
            System.out.print("Choice: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1": seriesManager.captureSeries(); break;
                case "2": seriesManager.searchSeries(); break;
                case "3": seriesManager.updateSeries(); break;
                case "4": seriesManager.deleteSeries(); break;
                case "5": seriesManager.seriesReport(); break;
                case "6": seriesManager.exitSeriesApplication(); break;
                default: System.out.println("Invalid option! Try again.");
            }
        }
    }
}
