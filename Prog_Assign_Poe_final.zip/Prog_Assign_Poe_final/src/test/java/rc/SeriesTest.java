package rc;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SeriesTest {

    /**
     * TestSearchSeries()
     * Supply the series id and confirm correct series is returned
     */
    @Test
    public void TestSearchSeries() {
        Series instance = new Series();
        instance.addSeries("S1", "Test Series", 13, 10);

        SeriesModel result = instance.searchSeries("S1");

        assertNotNull(result);
        assertEquals("S1", result.getSeriesId());
        assertEquals("Test Series", result.getSeriesName());
    }

    /**
     * TestSearchSeries_SeriesNotFound()
     * Supply an incorrect id, should return null
     */
    @Test
    public void TestSearchSeries_SeriesNotFound() {
        Series instance = new Series();
        instance.addSeries("S1", "Test Series", 13, 10);

        SeriesModel result = instance.searchSeries("S2"); // not added
        assertNull(result);
    }

    /**
     * TestUpdateSeries()
     * Update an existing series, should return true
     */
    @Test
    public void TestUpdateSeries() {
        Series instance = new Series();
        instance.addSeries("S1", "Old Name", 13, 10);

        boolean updated = instance.updateSeries("S1", "New Name", 15);

        assertTrue(updated);
        SeriesModel result = instance.searchSeries("S1");
        assertEquals("New Name", result.getSeriesName());
        assertEquals(15, result.getSeriesAge());
    }

    /**
     * TestDeleteSeries()
     * Delete an existing series, should return true
     */
    @Test
    public void TestDeleteSeries() {
        Series instance = new Series();
        instance.addSeries("S1", "Test Series", 13, 10);

        boolean deleted = instance.deleteSeries("S1");

        assertTrue(deleted);
        assertNull(instance.searchSeries("S1"));
    }

    /**
     * TestDeleteSeries_SeriesNotFound()
     * Try deleting a series that does not exist, should return false
     */
    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        Series instance = new Series();
        instance.addSeries("S1", "Test Series", 13, 10);

        boolean deleted = instance.deleteSeries("S2"); // not added

        assertFalse(deleted);
    }

    /**
     * TestSeriesAgeRestriction_AgeValid()
     * Supply a valid age, should return true
     */
    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        Series instance = new Series();
        boolean valid = instance.checkAgeRestriction(15);
        assertTrue(valid);
    }

    /**
     * TestSeriesAgeRestriction_SeriesAgeInValid()
     * Supply an invalid age, should return false
     */
    @Test
    public void TestSeriesAgeRestriction_SeriesAgeInValid() {
        Series instance = new Series();
        boolean valid = instance.checkAgeRestriction(20); // invalid
        assertFalse(valid);
    }
}
