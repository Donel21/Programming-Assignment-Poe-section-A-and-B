/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rc;

public class VIPPlayer extends Player {
    private int bonusPoints;

    // Constructor
    public VIPPlayer(String name, int bonusPoints) {
        super(name); // Call Player constructor
        this.bonusPoints = bonusPoints;
    }

    // Override to give VIP bonus
    @Override
    public void addScore(int points) {
        super.addScore(points + bonusPoints);
    }
}
