/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package rc;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class ProgPoeSectionB {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Array of questions
        String[] questions = {
            "What is the capital of South Africa?",
            "Which language is mainly used for Android development?",
            "What is 10 + 25?"
        };

        // Options for each question
        String[][] options = {
            {"1. Pretoria", "2. London", "3. Rome"},
            {"1. Python", "2. Java", "3. Swift"},
            {"1. 30", "2. 25", "3. 35"}
        };

        // Correct answers (index-based)
        int[] correctAnswers = {1, 2, 1};

        // Create players
        Player player1 = new Player("Don");
        VIPPlayer player2 = new VIPPlayer("Samu", 2); // Bob has bonus points

        Player[] players = {player1, player2}; // Store in array

        // Game loop for each player
        for (Player player : players) {
            System.out.println("\n=== " + player.getName() + "'s Turn ===");

            for (int i = 0; i < questions.length; i++) {
                System.out.println("\nQ" + (i + 1) + ": " + questions[i]);

                for (String option : options[i]) {
                    System.out.println(option);
                }

                System.out.print("Enter your answer (1-3): ");
                int answer = sc.nextInt();

                if (answer == correctAnswers[i]) {
                    player.addScore(5); // Correct = 5 points
                    System.out.println("✅ Correct!");
                } else {
                    System.out.println("❌ Wrong!");
                }
            }
        }

        // Show results
        System.out.println("\n===== Final Results =====");
        for (Player player : players) {
            player.displayReport();
        }

        // Determine winner
        Player winner = players[0];
        for (int i = 1; i < players.length; i++) {
            if (players[i].getScore() > winner.getScore()) {
                winner = players[i];
            }
        }

        System.out.println("\n🏆 Winner: " + winner.getName() +
                           " with " + winner.getScore() + " points!");
    }
}
