package rc;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PlayerTest {

    @Test
    public void testAddScoreForNormalPlayer() {
        Player player = new Player("Don");
        player.addScore(5);
        assertEquals(5, player.getScore(), "Normal player should get 5 points.");
    }

    @Test
    public void testAddScoreForVIPPlayer() {
        VIPPlayer vip = new VIPPlayer("Samu", 2);
        vip.addScore(5); 
        // VIP gets 5 + 2 bonus = 7
        assertEquals(7, vip.getScore(), "VIP player should get extra bonus points.");
    }

    @Test
    public void testWinnerCalculation() {
        Player p1 = new Player("Don");
        Player p2 = new Player("Samu");

        p1.addScore(10);
        p2.addScore(15);

        Player winner = (p1.getScore() > p2.getScore()) ? p1 : p2;

        assertEquals("Samu", winner.getName(), "Samu should be the winner with 15 points.");
    }
}
